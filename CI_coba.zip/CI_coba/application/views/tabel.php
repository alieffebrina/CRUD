<html>
	<head>
		<title>
			data mahasiswaa
		</title>
	</head>
	<body><?php echo "<h2>".$this->session->flashdata('pesan')."</h2>"; ?>
		<table border = 1 style ="border-collapse:collapse; width:70%">
			<tr style="background:grey">
				<th>NIM</th>
				<th>Nama</th>
				<th>Alamat</th>
				<th>Action</th>
			</tr>
			<?php foreach($data as $d) {?>
			<tr>
				<td><?php echo $d['NIM']; ?></td>
				<td><?php echo $d['nama']; ?></td>
				<td><?php echo $d['alamat']; ?></td>
				<td align ="center">
					<a href ="<?php echo base_url()."index.php/crud/edit_data/".$d['NIM']; ?>">Edit</a> ||
					<a href ="<?php echo base_url()."index.php/crud/do_delete/".$d['NIM']; ?>">Delete</a>
				</td>
			<tr>
			<?php } ?>
		</table>
		<a href = "<?php echo base_url()."index.php/crud/add_data"; ?>">Tambah Data</a>
	</body>
</html>
<ul class="business_catgnav  wow fadeInDown">
	<li>
		<figure class="bsbig_fig"> <a href="pages/single_page.html" class="featured_img"> <img alt="" src="<?php echo base_url()."aset/"; ?>images/featured_img1.jpg"> <span class="overlay"></span> </a>
			<figcaption> <a href="pages/single_page.html">Proin rhoncus consequat nisl eu ornare mauris</a> </figcaption>
			<p><?php echo $isi; ?></p>
		</figure>
	</li>
</ul>
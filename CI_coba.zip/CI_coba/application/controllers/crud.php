<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {
	public function index()
	{
		$data = $this->inimodel->GETMahasiswa();
		$this->load->view('tabel', array('data' => $data));
	}
	public function add_data(){
		$this->load->view('formadd');
	}
	public function do_insert(){
		/*
		CARA CEK APAKAH SUDAH BENAR YANG DI INPUTKAN
		echo "<pre>";
		print_r($_POST);
		echo "<pre>";
		*/
		$nim = $_POST['nim'];
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$data_insert =  array(
			"NIM" => $nim,
			"nama" => $nama,
			"alamat" => $alamat
		);
		$res = $this->inimodel->insertdata('tb_mahasiswa', $data_insert);
		if ($res >= 1){
			$this->session->set_flashdata('pesan','tambah data sukses');
			//echo "sukses";
			redirect('crud/index');
		}else {
			echo "gagal";
		}	
	}
	public function do_edit(){
		/*
		echo "<pre>";
		print_r($_POST);
		echo "<pre>";
		*/
		
		$nim = $_POST['nim'];
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$data_update =  array(
			"nama" => $nama,
			"alamat" => $alamat
		);
		$where = array('NIM' => $nim);
		$res = $this->inimodel->updatedata('tb_mahasiswa', $data_update, $where);
		if ($res >= 1){
			$this->session->set_flashdata('pesan','update data sukses');
			redirect('crud/index');
		}else {
			echo "gagal";
		}
	}
	public function do_delete($nim){
		$where = array('NIM' => $nim);
		$res = $this->inimodel->deletedata('tb_mahasiswa', $where);
		if ($res >= 1){
			$this->session->set_flashdata('pesan','delete data sukses');
			redirect('crud/index');
		}else{
			echo "gagal";
		}
	}
	public function edit_data($nim){
		$mhs = $this->inimodel->GETMahasiswa("where nim = '$nim'");
		/*echo "<pre>";
		print_r($data);
		echo "<pre>";
		*/
		$data = array(
			"nim" => $mhs[0]['NIM'],
			"nama" => $mhs[0]['nama'],
			"alamat" => $mhs[0]['alamat']
		);
		$this->load->view('formedit', $data);
	}
}

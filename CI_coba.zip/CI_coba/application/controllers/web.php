<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {
	public function index()
	{
		$datakonten = $this->inimodel->GetKonten();
		$datakategori = $this->inimodel->GetKategori();
		$dataisiawal = $this->inimodel->GetKonten('where kode_konten = 1');
		$datak = array(
			"datakonten" => $datakonten,
			"datakategori" => $datakategori,
			"isi" => $dataisiawal[0]['isi']
		);
		$this->load->view('index', $datak);
	}
	public function pilih($kode){
		$kd = $this->inimodel->GetKonten("where kode_konten = '$kode'");
		$datakonten = $this->inimodel->GetKonten();
		$datakategori = $this->inimodel->GetKategori();
		/*echo "<pre>";
		print_r($data);
		echo "<pre>";
		*/
		$datak = array(
			"datakonten" => $datakonten,
			"datakategori" => $datakategori,
			"nim" => $kd[0]['judul_konten'],
			"isi" => $kd[0]['isi']
		);
		$this->load->view('index', $datak);
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function index()
	{
		$data = $this->inimodel->GETMahasiswa();
		/*foreach ($data as $hasil){
			echo "nim : ".$hasil['NIM']."<br>";
			echo "nama : ".$hasil['nama']."<br>";
			echo "alamat : ".$hasil['alamat']."<Hr>";
		}*/
		$this->load->view('tabel', array('data' => $data));
		/*
		//menampilkan data array
		$data = array(
			'nama' => 'alief',
			'alamat' => 'demak',
			'kampus' => 'univ45'
		);
		$this->load->view('welcome_message', $data);*/
		//echo base_url();
		
		//Menampilkan database
		/*$data = $this->db->query("select * from tb_mahasiswa");
		foreach($data->result_array() as $hasil){ 
			echo "nim : ".$hasil['NIM']."<br>";
			echo "nama : ".$hasil['nama']."<br>";
			echo "alamat : ".$hasil['alamat']."<Hr>";
		}*/
	}
	/*public function cetak($satu = 'alief', $dua = 'cantik')
	{
		echo "saya function cetak dan function ".$satu."<br>";
		echo "saya function cetak dan function ".$dua;
	}*/
	public function insert(){
		$res = $this->inimodel->insertdata('tb_mahasiswa', array(
			"NIM" => "nim0003",
			"nama" => "rahma",
			"alamat" => "wonokromo"
		));
		if ($res >= 1){
			echo "sukses";
			// $this->load->view('welcome_message', $data);
		}else {
			echo "gagal";
		}
	}
	public function delete(){
		$res = $this->inimodel->deletedata('tb_mahasiswa', array("NIM" => "nim0003"));
		if ($res >= 1){
			echo "delete sukses";
		}else {
			echo "delete gagal";
		}
	}
	public function update(){
		$res = $this->inimodel->updatedata('tb_mahasiswa', array(
			"alamat" => "wongsorejo"
		), array("NIM" => "nim0003"));
		if ($res >= 1){
			echo "update sukses";
		}else {
			echo "update gagal";
		}
	}
	
	public function panggil(){
		$data = $this->db->query('select * from tb_mahasiswa');
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		*/
		echo "jumlah data =".$data->num_rows()."<br>";
		/*
		ini nampilin data dengan result
		foreach ($data->result() as $row){
			echo "nim =".$row->NIM."<br>";
			echo $row->nama."<br>";
			echo $row->alamat."<br><hr>";
		}
		
		ini nampilin data dengan result array
		foreach ($data->result_array() as $row){
			echo "nim =".$row['NIM']."<br>";
			echo $row['nama']."<br>";
			echo $row['alamat']."<br><hr>";
		}*/
		$row = $data ->row(); // ini nampilin satu baris yang pertama
		echo "nim = ".$row->NIM."<br>";
		echo "nama = ".$row->nama."<br>";
		echo "alamat = ".$row->alamat."<br>";
	}
}

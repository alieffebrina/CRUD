<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inimodel extends CI_model {
	public function GetMahasiswa($where = ""){
		$data = $this->db->query("select * from tb_mahasiswa ".$where);
		return $data->result_array();
	}
	public function insertdata($tablename, $data){
		$res = $this->db->insert($tablename, $data);
		return $res;
	}
	public function updatedata($tablename, $data, $where){
		$res = $this->db->update($tablename, $data, $where);
		return $res;
	}
	public function deletedata($tablename, $where){
		$res = $this->db->delete($tablename, $where);
		return $res;
	}
	public function GetKonten($where = ""){
		$datakonten = $this->db->query("select * from tb_konten ".$where);
		return $datakonten->result_array();
	}
	public function GetKategori($where = ""){
		$datakonten = $this->db->query("select * from tb_kategori ".$where);
		return $datakonten->result_array();
	}
}
